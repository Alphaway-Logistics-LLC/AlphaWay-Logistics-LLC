const quoteForm = document.querySelector('#quote-form');
const formMessage = document.querySelector('.form-message');

quoteForm.addEventListener('submit', (event) => {
	event.preventDefault();
	const email = new FormData(quoteForm).get('email');
	formMessage.textContent = `Thanks. We will reach out to ${email} shortly.`;
	quoteForm.reset();
});

const feedbackForm = document.querySelector('#feedback-form');
const feedbackMessage = document.querySelector('.feedback-message');

feedbackForm.addEventListener('submit', (event) => {
	event.preventDefault();
	const data = new FormData(feedbackForm);
	const sender = data.get('feedback-name') || 'Website visitor';
	const email = data.get('feedback-email') || 'Not provided';
	const body = `Name: ${sender}\nEmail: ${email}\n\nComments and suggestions:\n${data.get('feedback-message')}`;
	feedbackMessage.textContent = 'Opening your email app with your feedback addressed to Walter.';
	window.location.href = `mailto:walter@alphawaylogistics.com?subject=${encodeURIComponent('Website comments and suggestions')}&body=${encodeURIComponent(body)}`;
});
